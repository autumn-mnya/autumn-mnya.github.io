local mgWait = {0, 0, 0, 0, 0}
local mgBullet = {0, 0, 0, 0, 0}

-- Machine Gun port
ModCS.Arms.Shoot[4] = function(playerId)
    -- Set bullet based on level
    local level = ModCS.Arms.GetCurrent(playerId).level
    mgBullet[playerId + 1] = (level == 1) and 10 or (level == 2) and 11 or 12

    if not ModCS.Key.Shoot(playerId, true) then
        ModCS.Player.SetRensha(playerId, 5)
    end

    if ModCS.Arms.CountBulletWithID(4, playerId) > 5 then
        return
    end

    if ModCS.Key.Shoot(playerId, true) then
        if ModCS.Player.GetRensha(playerId) < 2 then
            ModCS.Player.SetRensha(playerId, ModCS.Player.GetRensha(playerId) + 1)
            return
        end

        ModCS.Player.SetRensha(playerId, 0)

        if not ModCS.Arms.UseAmmo(playerId, 1) then
            ModCS.Sound.Play(37)
            ModCS.Arms.SpawnEmpty(playerId)
            return
        end

        local x = ModCS.Player.GetX(playerId)
        local y = ModCS.Player.GetY(playerId)
        local direction = ModCS.Player.GetDirect(playerId)
        local bulletType = mgBullet[playerId + 1]
        local caretType = 3
        local soundId = (level == 3) and 49 or 32

        if ModCS.Player.IsLookingUp(playerId) then
            local offsetX = (direction == 0) and -3 or 3
            ModCS.Bullet.Spawn2(bulletType, x + offsetX, y - 8, 1, playerId)
            ModCS.Caret.Spawn(caretType, x + offsetX, y - 8, 0)
        elseif ModCS.Player.IsLookingDown(playerId) then
            local offsetX = (direction == 0) and -3 or 3
            ModCS.Bullet.Spawn2(bulletType, x + offsetX, y + 8, 3, playerId)
            ModCS.Caret.Spawn(caretType, x + offsetX, y + 8, 0)
        else
            local offsetX = (direction == 0) and -12 or 12
            local bulletDirection = (direction == 0) and 0 or 2
            ModCS.Bullet.Spawn2(bulletType, x + offsetX, y + 3, bulletDirection, playerId)
            ModCS.Caret.Spawn(caretType, x + offsetX, y + 3, 0)
        end

        ModCS.Sound.Play(soundId)
    else
        mgWait[playerId + 1] = mgWait[playerId + 1] + 1

        if mgWait[playerId + 1] > 0x70 then
            mgWait[playerId + 1] = 0
            ModCS.Arms.AddAmmo(playerId, 6)
        end
    end
end