require("arms")

ModCS.Npc.DisableNPCOptimization(true)