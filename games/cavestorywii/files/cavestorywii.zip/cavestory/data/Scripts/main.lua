-- Vanilla CS lua

ModCS.Mod.SetOpening(72, 100)
ModCS.Mod.SetStart(13, 10, 8, 200)

ModCS.Mod.SetBoosterFuel(50)
ModCS.Mod.SetVersion(1, 0, 0, 6)
ModCS.Mod.SetStartMyChar(3, 3, 2)
ModCS.Mod.SetIronheadRoom(31)
ModCS.Mod.SetTurbochargeEquips(8, 8)

-- Set map boss HP on boot of the game
ModCS.Mod.SetBossHP(1, 400)
ModCS.Mod.SetBossHP(2, 300)
ModCS.Mod.SetBossHP(3, 700)
ModCS.Mod.SetBossHP(4, 650)
ModCS.Mod.SetBossHP(5, 400)
ModCS.Mod.SetBossHP(6, 500)
ModCS.Mod.SetBossHP(7, 700)
ModCS.Mod.SetBossHP(8, 800)
ModCS.Mod.SetBossHP(9, 800)
ModCS.Mod.SetBossHP(10, 1200)