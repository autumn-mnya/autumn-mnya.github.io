require("arms")

-- Jenka's Nightmare lua

ModCS.Mod.SetOpening(1, 100)
ModCS.Mod.SetStart(2, 9, 12, 200)

ModCS.Mod.SetBoosterFuel(50)
ModCS.Mod.SetVersion(3, 0, 1, 0)
ModCS.Mod.SetStartMyChar(6, 6, 0)
ModCS.Mod.SetIronheadRoom(-1)
ModCS.Mod.SetTurbochargeEquips(1024, 8)

-- Set map boss HP on boot of the mod
ModCS.Mod.SetBossHP(1, 800)
ModCS.Mod.SetBossHP(2, 400)
ModCS.Mod.SetBossHP(3, 700)
ModCS.Mod.SetBossHP(4, 800)
ModCS.Mod.SetBossHP(5, 500)
ModCS.Mod.SetBossHP(6, 600)
ModCS.Mod.SetBossHP(7, 1000)
ModCS.Mod.SetBossHP(8, 666)

ModCS.Npc.DisableNPCOptimization(true)

-- Change the rect based on equip id 512
function ModCS.Game.Update()
    for i = 0, ModCS.Player.GetMaxPlayers() do
		if ModCS.Player.HasEquipped(i, 512) then
			ModCS.Player.SetRect(i, ModCS.Player.GetRect(i).left, ModCS.Player.GetRect(i).top + 32, ModCS.Player.GetRect(i).right, ModCS.Player.GetRect(i).bottom + 32)
		end
    end
end