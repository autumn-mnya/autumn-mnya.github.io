-- KASHUNGO port

ModCS.Mod.SetStart(22, 4, 13, 202)

-- Wonderful
ModCS.Npc.DisableNPCOptimization(true)