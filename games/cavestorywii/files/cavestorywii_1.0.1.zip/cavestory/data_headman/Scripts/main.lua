require("bullet")
require("npc")

-- Headman lua

ModCS.Mod.SetOpening(72, 100)
ModCS.Mod.SetStart(13, 10, 8, 200)

ModCS.Mod.SetBoosterFuel(75)
ModCS.Mod.SetVersion(0, 0, 0, 0)
ModCS.Mod.SetStartMyChar(3, 3, 2)
ModCS.Mod.SetIronheadRoom(31)
ModCS.Mod.SetTurbochargeEquips(8, 8)
ModCS.Mod.SetOmegaSpawn(10 * 0x10 * 0x200, 15 * 0x10 * 0x200)
ModCS.Mod.SetTitleColor(22, 1, 22)

ModCS.Mod.SetBossHP(1, 350)
ModCS.Mod.SetBossHP(2, 150)

ModCS.Mod.SetPhysics(0, 830)
ModCS.Mod.SetPhysics(1, 1535)
ModCS.Mod.SetPhysics(2, 80)
ModCS.Mod.SetPhysics(3, 45)
ModCS.Mod.SetPhysics(4, 88)
ModCS.Mod.SetPhysics(5, 32)
ModCS.Mod.SetPhysics(6, 60)
ModCS.Mod.SetPhysics(7, 1480)

ModCS.Mod.SetPhysics(8, 512)
ModCS.Mod.SetPhysics(9, 767)
ModCS.Mod.SetPhysics(10, 53)
ModCS.Mod.SetPhysics(11, 31)
ModCS.Mod.SetPhysics(12, 65)
ModCS.Mod.SetPhysics(13, 25)
ModCS.Mod.SetPhysics(14, 30)
ModCS.Mod.SetPhysics(15, 1211)

ModCS.Mod.SetPhysics(16, 0)

-- Headman swimming
function ModCS.Player.Act()
	if ModCS.Game.CanControl() then
		for i = 0, 3 do
			if ModCS.Player.TouchWater(i) then
				if ModCS.Key.Jump(i) then
					ModCS.Player.SetYM(i, ModCS.Player.GetPhysics(i, 15) * -1)
					ModCS.Sound.Play(15)
				end
			end
		end
	end
end