local frames_pre_home = 30
local fly_accel = 0x40 / 512
local speed_cap = 0x300 / 512

-- Experience
ModCS.Npc.Act[1] = function(npc)
	if npc.act_no == 0 then
		npc.act_no = 1
		npc.ani_no = ModCS.Random(1, 5)
		
		npc.xm = ModCS.Random(-0x200, 0x200) / 512
		npc.ym = ModCS.Random(-0x400, 0) / 512
		
		if not ModCS.Random(0, 1) == 0 then
			npc.direct = 0
		else
			npc.direct = 2
		end
	end
	
	if npc.count1 < frames_pre_home then
		if npc:TouchWater() then
			npc.ym = 0x15 / 512
		else
			npc.ym = 0x2A / 512
		end
	else
		-- Homing
		npc.xm = npc.xm + (npc:GetNearestPlayerX() < npc.x and -fly_accel or fly_accel)
		npc.ym = npc.ym + (npc:GetNearestPlayerY() < npc.y and -fly_accel or fly_accel)
		
		if npc.xm > speed_cap then
			npc.xm = speed_cap
		elseif npc.xm < -speed_cap then
			npc.xm = -speed_cap
		end
		
		if npc.ym > speed_cap then
			npc.ym = speed_cap
		elseif npc.ym < -speed_cap then
			npc.ym = -speed_cap
		end
	end
	
	-- Bounce off walls
	if npc:TouchLeftWall() and npc.xm < 0 then
		npc.xm = npc.xm * -1
	end
	
	if npc:TouchRightWall() and npc.xm > 0 then
		npc.xm = npc.xm * -1
	end
	
	-- Bounce off ceiling
	if npc:TouchCeiling() and npc.ym < 0 then
		npc.ym = npc.ym * -1
	end
	
	-- Bounce off floor
	if npc:TouchFloor() then
		ModCS.Sound.Play(45)
		npc.ym = -(0x280 / 512)
		npc.xm = 2 * (npc.xm / 3)
	end
	
	-- Play bounce song (and try to clip out of floor if we're stuck)
	if (npc.flag & 0xD) ~= 0 then
		ModCS.Sound.Play(45)
		npc.count2 = npc.count2 + 1
		if npc.count2 > 2 then
			npc.y = npc.y - 1
		end
	else
		npc.count2 = 0
	end
	
	-- Limit speed
	if npc.xm < -0x5FF / 512 then
		npc.xm = -0x5FF / 512
	end
	if npc.xm > 0x5FF / 512 then
		npc.xm = 0x5FF / 512
	end
	if npc.ym < -0x5FF / 512 then
		npc.ym = -0x5FF / 512
	end
	if npc.ym > 0x5FF / 512 then
		npc.ym = 0x5FF / 512
	end
	
	-- Move
	npc:Move()

	local rect = {
		{ 0, 16, 16, 32},
		{16, 16, 32, 32},
		{32, 16, 48, 32},
		{48, 16, 64, 32},
		{64, 16, 80, 32},
		{80, 16, 96, 32}
	}

	local rcNo = {
		{0, 0, 0, 0},
		{0, 0, 0, 0}
	}
	
	npc.ani_wait = npc.ani_wait + 1
	
	if npc.direct == 0 then
		if npc.ani_wait > 2 then
			npc.ani_wait = 0
			
			npc.ani_no = npc.ani_no + 1
			
			if npc.ani_no > 6 then
				npc.ani_no = 1
			end
		end
	else
		if npc.ani_wait > 2 then
			npc.ani_wait = 0

			npc.ani_no = npc.ani_no - 1
			if npc.ani_no < 2 then
				npc.ani_no = 6
			end
		end
	end
	
	npc:SetRect(rect[npc.ani_no][1], rect[npc.ani_no][2], rect[npc.ani_no][3], rect[npc.ani_no][4])
	
	if not npc.act_no == 0 then
		if npc.exp == 5 then
			npc:SetRect(i, npc:GetRect().left, npc:GetRect().top + 16, npc:GetRect().right, npc:GetRect().bottom + 16)
		elseif npc.exp == 20 then
			npc:SetRect(i, npc:GetRect().left, npc:GetRect().top + 32, npc:GetRect().right, npc:GetRect().bottom + 32)
		end
		
		npc.act_no = 1
	end
	
	npc.count1 = npc.count1 + 1

	if npc.count1 > 500 and npc.ani_no == 6 and npc.ani_wait == 2 then
		npc.cond = 0
	end

	-- Blink after 400 frames
	if npc.count1 > 400 then
		if (npc.count1 // 2) % 2 == 1 then
			npc:SetRect(rcNo[1][1], rcNo[1][2], rcNo[1][3], rcNo[1][4])
		end
	end
end

-- Santa's key edits
ModCS.Npc.Act[14] = function(npc)
	local oldY = npc.y
	
	npc:ActCode()
	npc.y = oldY
	npc.ym = 0
end

-- Critter npc edits
ModCS.Npc.Act[64] = function(npc)
	local oldX = npc.x
	
	npc:ActCode()
	npc.x = oldX
	npc.xm = 0
end

-- Bat edits (bombat)
ModCS.Npc.Act[65] = function(npc)
	npc:ActCode() -- run normal bat code

	local explode = false
	
	if npc.life <= 1000 then
		explode = true
	end
	
	if npc:TouchPlayer() then
		explode = true
	end
	
	-- Delete itself
	if npc.life == 0 then
		npc.cond = 0
	end
	
	
	if explode then
		ModCS.Sound.Play(35)
		
		npc:SetHitbox(0x3800 / 512, 0x3800 / 512, 0x3800 / 512, 0x3800 / 512)
		
		ModCS.Npc.SetDestroySmoke(npc.x * 512, npc.y * 512, 0x20, 0x32)
		
		npc.life = 0
	end
end

-- Gravekeeper edits (nose)
ModCS.Npc.Act[80] = function(npc)
	local rcGraveLeft = {
		{0, 64, 24, 88},
		{24, 64, 48, 88},
		{0, 64, 24, 88},
		{48, 64, 72, 88},
		{72, 64, 96, 88},
		{96, 64, 120, 88},
		{120, 64, 144, 88}
	}

	local rcGraveRight = {
		{0, 88, 24, 112},
		{24, 88, 48, 112},
		{0, 88, 24, 112},
		{48, 88, 72, 112},
		{72, 88, 96, 112},
		{96, 88, 120, 112},
		{120, 88, 144, 112}
	}

	if npc.act_no == 0 then
		npc.ani_no = 1 -- has to be set to 1 on act_no 0
		npc:SetBit(0x20)
		npc.act_no = 1
		npc.damage = 0
		npc:OffsetHitbox(4, 0, 0, 0)
	elseif npc.act_no == 1 then
		npc.ani_no = 1
		
		if npc.x - 128 < npc:GetNearestPlayerX() and npc.x + 128 > npc:GetNearestPlayerX() and npc.y - 48 < npc:GetNearestPlayerY() and npc.y + 32 > npc:GetNearestPlayerY() then
			npc.ani_wait = 0
			npc.act_no = 2
		end
		
		if npc.shock > 0 then
			npc.ani_no = 1
			npc.ani_wait = 0
			npc.act_no = 2
			npc:SetBit(0x20)
		end
		
		if npc:GetNearestPlayerX() < npc.x then
			npc.direct = 0
		else
			npc.direct = 2
		end
	elseif npc.act_no == 2 then -- attack mode
		npc.ani_wait = npc.ani_wait + 1
		if (npc.ani_wait > 6) then
			npc.ani_wait = 0
			npc.ani_no = npc.ani_no + 1
		end
		
		if (npc.ani_no > 4) then
			npc.ani_no = 1
		end
		
		if npc.x - 16 < npc:GetNearestPlayerX() and npc.x + 16 > npc:GetNearestPlayerX() then
			npc:SetHitbox(18, npc:GetHitbox().top, npc:GetHitbox().back, npc:GetHitbox().bottom)
			npc.act_wait = 0
			npc.act_no = 3
			npc:SetBit(0x20)
			ModCS.Sound.Play(34)
			if npc.direct == 0 then
				npc.xm = -0x400 / 512
			else
				npc.xm = 0x400 / 512
			end
		end
		
		if npc:GetNearestPlayerX() < npc.x then
			npc.direct = 0
			npc.xm = -0x100 / 512
		else
			npc.direct = 2
			npc.xm = 0x100 / 512
		end
	elseif npc.act_no == 3 then
		npc.xm = 0
		
		npc.act_wait = npc.act_wait + 1
		if npc.act_wait > 40 then
			npc.act_wait = 0
			npc.act_no = 4
			ModCS.Sound.Play(106)
		end
		
		npc.ani_no = 5
	elseif npc.act_no == 4 then
		npc.damage = 10
		
		npc.act_wait = npc.act_wait + 1
		
		if npc.act_wait > 2 then
			npc.act_wait = 0
			npc.act_no = 5
		end
		
		npc.ani_no = 6
	elseif npc.act_no == 5 then
		npc.ani_no = 7
		
		npc.act_wait = npc.act_wait + 1
		
		if npc.act_wait > 60 then
			npc.act_no = 0
		end
	end
	
	if npc.xm < 0 and npc:TouchLeftWall() then
		npc.xm = 0
	end
	if npc.xm > 0 and npc:TouchRightWall() then
		npc.xm = 0
	end
	
	npc.ym = npc.ym + 0x20 / 512
	
	if npc.xm > 0x400 / 512 then
		npc.xm = 0x400 / 512
	end

	if npc.xm < -0x400 / 512 then
		npc.xm = -0x400 / 512
	end

	if npc.ym > 0x5FF / 512 then
		npc.ym = 0x5FF / 512
	end

	if npc.ym < -0x5FF / 512 then
		npc.ym = -0x5FF / 512
	end
	
	-- add xm/ym to x/y
	npc:Move()

	-- Set the NPC's sprite depending on the direction
	if npc.direct == 0 then
		npc:SetRect(rcGraveLeft[npc.ani_no][1], rcGraveLeft[npc.ani_no][2], rcGraveLeft[npc.ani_no][3], rcGraveLeft[npc.ani_no][4])
	else
		npc:SetRect(rcGraveRight[npc.ani_no][1], rcGraveRight[npc.ani_no][2], rcGraveRight[npc.ani_no][3], rcGraveRight[npc.ani_no][4])
	end
end