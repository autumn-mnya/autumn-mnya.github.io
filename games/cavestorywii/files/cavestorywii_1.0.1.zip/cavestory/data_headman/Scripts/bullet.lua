function HeadmanPolarStar(bul)
	bul:ActCode()
	
	-- Do random speed
	if bul.act_no == 1 then
		if bul.count2 == 0 then
			if bul.direct == 1 or bul.direct == 3 then
				bul.xm = bul.xm + ModCS.Random(-0x12C,0x12C) / 512
			else
				bul.ym = bul.ym + ModCS.Random(-0x64, 0x64) / 512
			end
			
			bul.count2 = 1
		end
	end
end

-- Headman polar star
ModCS.Bullet.Act[4] = HeadmanPolarStar
ModCS.Bullet.Act[5] = HeadmanPolarStar
ModCS.Bullet.Act[6] = HeadmanPolarStar