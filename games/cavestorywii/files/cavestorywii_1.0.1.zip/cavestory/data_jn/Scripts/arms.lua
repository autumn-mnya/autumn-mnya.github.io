local snakeWait = {0, 0, 0, 0, 0}
local snakeBullet = {0, 0, 0, 0, 0}

-- JN Snake port
-- This function isnt compatible with normal ModCS, it's specifically for the wii version.
ModCS.Arms.Shoot[1] = function(playerId)
	if ModCS.Arms.GetCurrent(playerId).level == 1 then
		snakeBullet[playerId+1] = 1
	elseif ModCS.Arms.GetCurrent(playerId).level == 2 then
		snakeBullet[playerId+1] = 2
	else
		snakeBullet[playerId+1] = 3
	end
	
	if ModCS.Arms.CountBulletWithID(1, playerId) > 3 then
		return
	end
		
	if ModCS.Key.Shoot(playerId) then
		if not ModCS.Arms.UseAmmo(playerId, 1) then
			-- Spawn empty caret if out of ammo
			ModCS.Sound.Play(37)
			ModCS.Arms.SpawnEmpty(playerId)
			return
		else
			if ModCS.Player.IsLookingUp(playerId) then
				if ModCS.Player.GetDirect(playerId) == 0 then
					ModCS.Bullet.Spawn2(snakeBullet[playerId+1], ModCS.Player.GetX(playerId) - 3, ModCS.Player.GetY(playerId) - 10, 1, playerId)
					ModCS.Caret.Spawn(3, ModCS.Player.GetX(playerId) - 3, ModCS.Player.GetY(playerId) - 10, 0)
				else
					ModCS.Bullet.Spawn2(snakeBullet[playerId+1], ModCS.Player.GetX(playerId) + 3, ModCS.Player.GetY(playerId) - 10, 1, playerId)
					ModCS.Caret.Spawn(3, ModCS.Player.GetX(playerId) + 3, ModCS.Player.GetY(playerId) - 10, 0)
				end
			elseif ModCS.Player.IsLookingDown(playerId) then
				if ModCS.Player.GetDirect(playerId) == 0 then
					ModCS.Bullet.Spawn2(snakeBullet[playerId+1], ModCS.Player.GetX(playerId) - 3, ModCS.Player.GetY(playerId) + 10, 3, playerId)
					ModCS.Caret.Spawn(3, ModCS.Player.GetX(playerId) - 3, ModCS.Player.GetY(playerId) + 10, 0)
				else
					ModCS.Bullet.Spawn2(snakeBullet[playerId+1], ModCS.Player.GetX(playerId) + 3, ModCS.Player.GetY(playerId) + 10, 3, playerId)
					ModCS.Caret.Spawn(3, ModCS.Player.GetX(playerId) + 3, ModCS.Player.GetY(playerId) + 10, 0)
				end
			else
				if ModCS.Player.GetDirect(playerId) == 0 then
					ModCS.Bullet.Spawn2(snakeBullet[playerId+1], ModCS.Player.GetX(playerId) - 6, ModCS.Player.GetY(playerId) + 2, 0, playerId)
					ModCS.Caret.Spawn(3, ModCS.Player.GetX(playerId) - 12, ModCS.Player.GetY(playerId) + 2, 0)
				else
					ModCS.Bullet.Spawn2(snakeBullet[playerId+1], ModCS.Player.GetX(playerId) + 6, ModCS.Player.GetY(playerId) + 2, 2, playerId)
					ModCS.Caret.Spawn(3, ModCS.Player.GetX(playerId) + 12, ModCS.Player.GetY(playerId) + 2, 0)
				end
			end
			
			ModCS.Sound.Play(33)
		end
    else
        snakeWait[playerId + 1] = snakeWait[playerId + 1] + 1
        
        if ModCS.Player.HasEquipped(playerId, 8) then
            if snakeWait[playerId + 1] > 20 then
                snakeWait[playerId + 1] = 0 
                ModCS.Arms.AddAmmo(playerId, 1)
            end
        else
            if snakeWait[playerId + 1] == 60 then
                snakeWait[playerId + 1] = 0 
                ModCS.Arms.AddAmmo(playerId, 1)
            end
        end
    end
end