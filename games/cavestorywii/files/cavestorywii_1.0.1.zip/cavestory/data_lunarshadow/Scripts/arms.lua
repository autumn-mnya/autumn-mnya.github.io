-- ilikebreadtoomuch (yasinbread) made this
local function ExplodingPolarStar(bul)
	local id = bul.id
	bul.count2 = bul.count2 + 1
	if (bul.count2 > bul.life_count) then
		bul:Delete()
		ModCS.Caret.Spawn(3, bul.x, bul.y)

		for i=0,3,1 do
			ModCS.Bullet.Spawn(id - 1, bul.x, bul.y, i)
		end

		return
	end

	bul:ActCode()
end

ModCS.Bullet.Act[5] = ExplodingPolarStar
ModCS.Bullet.Act[6] = ExplodingPolarStar