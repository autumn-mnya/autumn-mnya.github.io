require("arms")

-- Lunar Shadow by Kim
ModCS.Mod.SetStart(13, 4, 26, 200)

ModCS.Npc.DisableNPCOptimization(true)

function ModCS.Player.Act()
	-- Lunar Shadow swimming
	if ModCS.Game.CanControl() then
		for i = 0, ModCS.Player.GetMaxPlayers() do
			if ModCS.Player.IsPlaying(i) then
				if ModCS.Player.TouchWater(i) then
					if ModCS.Key.Jump(i, true) then
						ModCS.Player.SetYM(i, ModCS.Player.GetYM(i) - 88)
					end
				end
			end
		end
	end
end