<Cortex Challenge ~ Kayo H. 2020>

This mod is a simple challenge mod, just made in 3 days for people to enjoy.