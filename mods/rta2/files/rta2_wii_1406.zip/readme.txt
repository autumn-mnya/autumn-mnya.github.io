--------------
How to install
--------------
1) Copy all the files inside the sd_card folder to the root of your sd card
2) you're done