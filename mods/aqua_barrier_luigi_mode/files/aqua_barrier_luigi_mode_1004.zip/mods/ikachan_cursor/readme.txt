This restores the unused Ikachan cursor, described here: https://tcrf.net/Cave_Story#Other_Graphics
