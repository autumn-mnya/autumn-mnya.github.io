The mod replaces the game's controller system, allowing better support for XInput devices. The controls are as follows:

D-Pad / Left Analogue Stick - Movement
A / Y - Jump
X / B - Shoot
LB / LT - Previous weapon
RB / RT - Next weapon
Start - Inventory
Back - Map
