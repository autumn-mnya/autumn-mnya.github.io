This mod replicates the HUD from the 3DS eShop port, which gives you more room to look around.
