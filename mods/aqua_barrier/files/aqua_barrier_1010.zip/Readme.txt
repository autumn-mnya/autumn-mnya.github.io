<Original Game:>
<Cave Story ~ Doukutsu Monogatari> (C) Studio Pixel 2004

<AQUA BARRIER ~ Kayo> 2020

Credits:
<123a (Making the entirety of Chapter 2, and multiple sprites in the mod)>
<Fire (Making multiple huge sprites in the mod)>
<Woddles (Playtesting, added SICK NASTY SPEEDRUN STRATS in the FINAL LEVEL??)>
<Studio Pixel (Making the original game!)>
<2dbro (ORGS)>
<Clownacy (DLL Mod Loader)>
<Noxid (Booster's Lab)>
<EnlightenOne (XML Mods)>
<BLink (<BUY and <SEL hack>
<Milon Luxy (Original Cave Story Beta Graphics mod, for some graphics used.)>
<branflakes (final level remixes)>
<Lena Raine (Original Celeste Music used for Branflakes remixes)>

<The Mod>

AQUA BARRIER is a Cave Story mod based around collecting "Power Souls" to progress through the story.
Playing Cave Story to the best ending is NOT required to understand this mod.