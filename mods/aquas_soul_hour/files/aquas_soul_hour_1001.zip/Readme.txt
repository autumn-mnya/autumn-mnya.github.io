<AQUAS SOUL HOUR ~ ChampionX Team 2019>

This mod is a fast-paced challenge mod!

Notes:
-MultiSave couldn't be removed from AQUA BARRIER correctly
-21:9 aspect ratio is to give you more room to view the map