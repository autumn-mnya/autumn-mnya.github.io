This mod changes the game's control scheme to a WASD layout. The controls are as follows:

W - Up
A - Left
S - Down
D - Right
O - Shoot
P - Jump
[ - Inventory
] - Map
9 - Previous weapon
0 - Next weapon
