This dll includes compatibility with the "pause menu" dll, and it is recommended you install that.
https://github.com/autumn-mnya/cavestory-pause-mod/releases/tag/1.0.0

Custom Fonts:
This dll changes how fonts work. Fonts load from the "data\Font" folder now, using the list defined in "font.list.yaml".

The first font is the default font loaded on new game. The Name is what shows up in game in the options menu. The filename is what gets loaded from "data\Font".

It is recommended you keep the 3 default fonts at least as options, even if you want your mod to have a different default font.

Releasing mods with this dll:
It is advised that when you release a mod using this dll, you first delete the config file for it found in "data\Config", that being "SDL.dat".

This is so that it has default settings when someone opens your mod.