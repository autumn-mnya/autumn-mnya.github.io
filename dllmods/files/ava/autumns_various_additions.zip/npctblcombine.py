-- Define the NPC table class
local NpcTblEntry = {
    bits = 0,
    life = 0,
    surf = 0,
    hit_voice = 0,
    destroy_voice = 0,
    size = 0,
    exp = 0,
    damage = 0,
    hit = {0, 0, 0, 0},
    view = {0, 0, 0, 0}
}

-- NPC table constructor
local function NpcTbl(fileName)
    local self = {
        data = {}
    }
    
    if fileName then
        self:loadFromFile(fileName)
    end

    function self:size()
        return #self.data
    end

    function self:loadFromFile(fileName)
        self.data = {}
        
        local fileSize = love.filesystem.getInfo(fileName).size
        local numEntries = math.floor(fileSize / 24)
        local f = assert(love.filesystem.newFile(fileName, "rb"))
        
        for i = 1, numEntries do
            local npc = {
                bits = f:read(2):unpack("<H"),
                life = f:read(2):unpack("<H"),
                surf = f:read(1):unpack("B"),
                destroy_voice = f:read(1):unpack("B"),
                hit_voice = f:read(1):unpack("B"),
                size = f:read(1):unpack("B"),
                exp = f:read(4):unpack("<i"),
                damage = f:read(4):unpack("<i"),
                hit = {f:read(4):byte(1, 4)},
                view = {f:read(4):byte(1, 4)}
            }
            table.insert(self.data, npc)
        end

        f:close()
    end

    function self:writeToFile(fileName)
        local f = assert(love.filesystem.newFile(fileName, "wb"))

        for _, npc in ipairs(self.data) do
            f:write(string.pack("<H", npc.bits))
            f:write(string.pack("<H", npc.life))
            f:write(string.pack("B", npc.surf))
            f:write(string.pack("B", npc.destroy_voice))
            f:write(string.pack("B", npc.hit_voice))
            f:write(string.pack("B", npc.size))
            f:write(string.pack("<i", npc.exp))
            f:write(string.pack("<i", npc.damage))
            f:write(string.pack("BBBB", unpack(npc.hit)))
            f:write(string.pack("BBBB", unpack(npc.view)))
        end

        f:close()
    end

    return self
end

-- Main program (Love2D specific)
local npctbl1, npctbl2

function love.load()
    print("Enter the path to npc.tbl #1:")
end

function love.textinput(text)
    if not npctbl1 then
        tbl1Path = tbl1Path .. text
    elseif not npctbl2 then
        tbl2Path = tbl2Path .. text
    end
end

function love.keypressed(key)
    if key == "return" then
        if not npctbl1 then
            npctbl1 = NpcTbl(tbl1Path)
            print("\nLoaded " .. npctbl1:size() .. " NPCs from npc.tbl #1")
            print("\nEnter the path to npc.tbl #2:")
            tbl1Path = "" -- Reset tbl1Path for npc.tbl #2 input
        elseif not npctbl2 then
            npctbl2 = NpcTbl(tbl2Path)
            print("\nLoaded " .. npctbl2:size() .. " NPCs from npc.tbl #2")

            if npctbl2:size() > npctbl1:size() then
                print("\nHow would you like to combine these two npc.tbls?")
                print("1: Add all " .. npctbl2:size() .. " NPCs from npc.tbl #2 (npc.tbl #1 will have " .. (npctbl1:size() + npctbl2:size()) .. " NPCs after)")
                print("2: Add only NPCs " .. (npctbl1:size() + 1) .. "-" .. npctbl2:size() .. " from npc.tbl #2 to npc.tbl #1")

                while true do
                    local option = tonumber(io.read())
                    if option == 1 or option == 2 then
                        combineTables(option)
                        break
                    else
                        print("Please enter a valid option number")
                    end
                end
            else
                print("\nGoing to add " .. npctbl2:size() .. " NPCs from npc.tbl #2 to npc.tbl #1")
                combineTables(1) -- Combine all NPCs from npc.tbl #2
            end
        end
    end
end

function combineTables(option)
    if option == 1 then
        for _, npc in ipairs(npctbl2.data) do
            table.insert(npctbl1.data, npc)
        end
    elseif option == 2 then
        for i = npctbl1:size() + 1, npctbl2:size() do
            table.insert(npctbl1.data, npctbl2.data[i])
        end
    end

    print("\nEnter the file name to save the combined npc.tbl:")
    local outputFileName = io.read()
    npctbl1:writeToFile(outputFileName)
    print("Wrote " .. npctbl1:size() .. " NPCs to " .. outputFileName)
    print("All done! Press Enter to exit.")
    io.read() -- Wait for user input before exiting
end
