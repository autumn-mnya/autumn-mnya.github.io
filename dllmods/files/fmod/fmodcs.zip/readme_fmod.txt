INSTALLATION:
Drag everything in this folder into your Mod folder!

Make sure you already have Clownacy's DLL Mod Loader, and add "fmodcs" to the mods.txt file.

Please put this into your mod credits:
Made using FMOD Audio by Firelight Technologies Pty Ltd.

Group Chart:
0000 - Music
0001 - Ambience
0002 - ?
0003 - ?
0004 - ?
0005 - ?
0006 - ?
0007 - ?

# If there was more documentation needed, there would be more here. For now, this is all. #